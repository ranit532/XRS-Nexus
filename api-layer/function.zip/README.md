# API Layer

RESTful APIs for UI and external consumers (status, lineage, metadata).

- Azure API Management
- FastAPI (Python) or ASP.NET Core
- OpenAPI/Swagger
- Cosmos DB
